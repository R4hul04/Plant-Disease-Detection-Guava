# Image-Based-Plant-Disease-Detection
This is the required code of the paper /  report named Image Based Plant Disease Detection

##### Steps ! #####
1. Download the repository.
2. Open the folder in an appropriate python IDE.
3. The IDE will prompt you to create python environment therefore create.
4. Install the required libraries from the requirements.txt file.
5. Execute the code.
